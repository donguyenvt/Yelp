//
//  SegmentedCell.swift
//  Yelp
//
//  Created by Nguyen T Do on 3/20/16.
//  Copyright © 2016 Timothy Lee. All rights reserved.
//

import UIKit

@objc protocol SortBySegmentedCellDelegate {
    optional func sortBySegmentedCell(segmentedCell: SegmentedCell, didChangeValue value: Int)
}

class SegmentedCell: UITableViewCell {

    @IBOutlet weak var sortBySegmentedControl: UISegmentedControl!
    
    weak var delegate: SortBySegmentedCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        sortBySegmentedControl.addTarget(self, action: "selectedIndexChanged", forControlEvents: UIControlEvents.ValueChanged)
        
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func selectedIndexChanged() {
        delegate?.sortBySegmentedCell?(self, didChangeValue: sortBySegmentedControl.selectedSegmentIndex)
    }

}
