//
//  CategoriesCell.swift
//  Yelp
//
//  Created by Nguyen T Do on 3/20/16.
//  Copyright © 2016 Timothy Lee. All rights reserved.
//

import UIKit

@objc protocol CategoriesCellDelegate {
    optional func categoriesSwitchCell(switchCell: CategoriesCell, didChangeValue value: Bool)
}

class CategoriesCell: UITableViewCell {

    @IBOutlet weak var categoriesLabel: UILabel!
    @IBOutlet weak var categoriesOnSwitch: UISwitch!
    
    weak var delegate: CategoriesCellDelegate?
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        categoriesOnSwitch.addTarget(self, action: "categoriesSwitchValueChanged", forControlEvents: UIControlEvents.ValueChanged)
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func categoriesSwitchValueChanged() {
        delegate?.categoriesSwitchCell?(self, didChangeValue: categoriesOnSwitch.on)
    }

}
