//
//  YelpSearchSettings.swift
//  Yelp
//
//  Created by Nguyen T Do on 3/19/16.
//  Copyright © 2016 Timothy Lee. All rights reserved.
//

import UIKit

class YelpSearchSettings {
    var distance = 30000
    var sortBy = 0
    var deals = false
    var categories = ["vietnamese"]
    var tempCategoriesOn = ["vietnamese"]
    var tempCategoriesOff = ["vietnamese"]
    
    init() {
    }
    
}
