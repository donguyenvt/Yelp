//
//  DistanceSegmentedCell.swift
//  Yelp
//
//  Created by Nguyen T Do on 3/20/16.
//  Copyright © 2016 Timothy Lee. All rights reserved.
//

import UIKit

@objc protocol DistanceSegmentedCellDelegate {
    
    optional func distanceSegmentedCell(segmentedCell: DistanceSegmentedCell, didChangeValue value: Int)
}

class DistanceSegmentedCell: UITableViewCell {
    
    @IBOutlet weak var distanceSegmentedControl: UISegmentedControl!
    
    weak var delegate: DistanceSegmentedCellDelegate?

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        distanceSegmentedControl.addTarget(self, action: "selectedIndexChangedForDistance", forControlEvents: UIControlEvents.ValueChanged)
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func selectedIndexChangedForDistance() {
        delegate?.distanceSegmentedCell?(self, didChangeValue: distanceSegmentedControl.selectedSegmentIndex)
    }

}
